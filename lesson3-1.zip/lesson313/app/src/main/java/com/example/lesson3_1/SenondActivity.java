package com.example.lesson3_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SenondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senond);
       String messing;
     messing = getIntent().getExtras().getString("username");
     TextView infoTextView = (TextView)findViewById(R.id.text_view);
     infoTextView.setText(messing);
    }
}